Project Details
For the 2nd assignment, we decided to go for a covid 19 theme which consists of general information of the virus and what tips could be provided to prevent getting infected by the virus. Overall, purpose of creating this site is to be used as general knowledge to the public who hasn't heard of the virus and would like being enlightened by this site.

Design Process
This website is focused towards general public no matter what age. What we want to achieve from creating this site is to let public understand what the virus is and what to do to prevent getting infected.

Features

live covid status of what is happening currently around singapore such eg. Total cases,total deaths,Currently infected,recovered.

A short optional 3 questions quiz for the general public

Technologies Used

Roles assigned

Izz :
Front End / Back End

- Did the coding for Ui interface for the website.
- Implemented covid api status for countries.

- Did a short optional quiz for the general public.
- Implemented live covid status for countries
- Wrote all the guides for prevention and symptoms of covid 19.

Dani :
N/A

Media
Photos used is from google images.

Acknowledgements

- I received inspirations from w3schools as the website gave me a ton of elements to work on while scrolling the site.
- Used https://covid19api.com for implementing the live status

Video Link For Assignment
https://drive.google.com/file/d/1mqBFjnAfc8pJLE0QuWWY3eHpeXzcpJkj/view?usp=sharing

Github Page Link
https://github.com/IzzFikrii/IDAssignment2.git
